Premise:
A guitar hero-esque game that will allow the player to play up to ANY (given three)levels of guitar 
hero. Once they have finished the game there will be a game over screen and the option to see 
the highest scores in the game so far.
There is an additional setting where the user will be able to manually make a 
file that can create a guitar hero level. Uses pyaudio and Tkinter, has mouse and key movements.


Modules Needed:
tkinter is not needed to download, pyaudio download can be found:
https://abhgog.gitbooks.io/pyaudio-manual/content/installation.html




